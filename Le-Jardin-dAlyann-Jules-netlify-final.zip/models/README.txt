Reserved for 3D model files if the garden is extended with external meshes.

