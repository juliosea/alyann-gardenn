﻿import * as THREE from "https://unpkg.com/three@0.160.0/build/three.module.js";

const canvas = document.getElementById("garden-canvas");
const introOverlay = document.getElementById("intro-overlay");
const introText = document.getElementById("intro-text");
const flowerCountEl = document.getElementById("flower-count");
const dailyMessageEl = document.getElementById("daily-message");
const cycleLabelEl = document.getElementById("cycle-label");
const followCatBtn = document.getElementById("follow-cat-btn");
const audioBtn = document.getElementById("audio-btn");
const hud = document.getElementById("hud");
const mobileNote = document.getElementById("mobile-note");
const timerDaysEl = document.getElementById("timer-days");
const timerHoursEl = document.getElementById("timer-hours");
const timerMinutesEl = document.getElementById("timer-minutes");
const timerSecondsEl = document.getElementById("timer-seconds");

const relationshipStart = new Date(2026, 1, 9);
const isMobile =
  window.matchMedia("(max-width: 900px)").matches ||
  /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);

const CONFIG = {
  gardenRadius: 6.2,
  dayCycleSeconds: 230,
  grassCount: isMobile ? 130 : 240,
  butterflyCount: isMobile ? 5 : 8,
  fireflyCount: isMobile ? 36 : 64,
  cloudCount: isMobile ? 7 : 12,
  stoneCount: isMobile ? 12 : 22,
  rainDropCount: isMobile ? 180 : 360,
  shootingStarCount: isMobile ? 2 : 4,
  shadow: !isMobile,
};

const clamp = THREE.MathUtils.clamp;
const lerp = THREE.MathUtils.lerp;
const Y_AXIS = new THREE.Vector3(0, 1, 0);

function rand(min, max) {
  return min + Math.random() * (max - min);
}

function smoothstep(edge0, edge1, x) {
  const t = clamp((x - edge0) / (edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}

function lerpAngle(from, to, t) {
  const delta = Math.atan2(Math.sin(to - from), Math.cos(to - from));
  return from + delta * t;
}

function randomInCircle(radius) {
  const angle = rand(0, Math.PI * 2);
  const r = Math.sqrt(Math.random()) * radius;
  return new THREE.Vector3(Math.cos(angle) * r, 0, Math.sin(angle) * r);
}

function pickWeighted(items) {
  const total = items.reduce((sum, item) => sum + item.weight, 0);
  let value = Math.random() * total;
  for (const item of items) {
    value -= item.weight;
    if (value <= 0) {
      return item.value;
    }
  }
  return items[items.length - 1].value;
}

function daysTogether() {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const start = new Date(
    relationshipStart.getFullYear(),
    relationshipStart.getMonth(),
    relationshipStart.getDate(),
  );
  const diff = Math.floor((today - start) / 86400000);
  return Math.max(0, diff + 1);
}

function updateLoveTimer() {
  const now = new Date();
  const diffMs = Math.max(0, now.getTime() - relationshipStart.getTime());
  const totalSeconds = Math.floor(diffMs / 1000);

  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (timerDaysEl) {
    timerDaysEl.textContent = `${days} jours`;
  }
  if (timerHoursEl) {
    timerHoursEl.textContent = `${hours} heures`;
  }
  if (timerMinutesEl) {
    timerMinutesEl.textContent = `${minutes} minutes`;
  }
  if (timerSecondsEl) {
    timerSecondsEl.textContent = `${seconds} secondes`;
  }
}

const romanticMessages = [
  "Chaque jour avec toi est une fleur de plus.",
  "Le jardin grandit comme mon amour.",
  "Ton sourire allume les lucioles de ma nuit.",
  "Nos souvenirs poussent comme des fleurs sous la pluie douce.",
  "Ton prenom rechauffe mon ciel du soir.",
  "Meme le vent ralentit pour nous regarder.",
  "Dans ce jardin, chaque petale dit je t aime.",
  "Le silence devient poesie quand tu es la.",
  "Le temps passe, mon amour fleurit.",
  "Tu es la lumiere calme de mon monde.",
];

const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: !isMobile,
  powerPreference: "high-performance",
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isMobile ? 1.5 : 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = CONFIG.shadow;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(new THREE.Color("#5f7593"), 0.022);

const camera = new THREE.PerspectiveCamera(
  isMobile ? 58 : 50,
  window.innerWidth / window.innerHeight,
  0.1,
  120,
);
camera.position.set(0, 1.2, 1.65);

const smoothLookTarget = new THREE.Vector3(0, 0.6, 0);
const clock = new THREE.Clock();
let simTime = 0;
let followCatEnabled = false;

const cycleState = {
  progress: 0,
  dayFactor: 0.35,
  sunsetFactor: 0,
  nightFactor: 0.65,
  label: "Nuit magique",
};

const colors = {
  skyTopDay: new THREE.Color("#8ac8ff"),
  skyTopSunset: new THREE.Color("#ff8e74"),
  skyTopNight: new THREE.Color("#111e43"),
  skyTopRain: new THREE.Color("#5c6879"),
  skyBottomDay: new THREE.Color("#ffe0b2"),
  skyBottomSunset: new THREE.Color("#ffb180"),
  skyBottomNight: new THREE.Color("#22345e"),
  skyBottomRain: new THREE.Color("#72849b"),
  fogDay: new THREE.Color("#95acc0"),
  fogNight: new THREE.Color("#243456"),
  fogRain: new THREE.Color("#6f7e8f"),
  sunDay: new THREE.Color("#ffe3b4"),
  sunSunset: new THREE.Color("#ffbe8f"),
};

const tmpColorA = new THREE.Color();
const tmpColorB = new THREE.Color();

const skyUniforms = {
  uTop: { value: colors.skyTopNight.clone() },
  uBottom: { value: colors.skyBottomNight.clone() },
  uHaze: { value: 0.15 },
};

const sky = new THREE.Mesh(
  new THREE.SphereGeometry(50, 40, 24),
  new THREE.ShaderMaterial({
    side: THREE.BackSide,
    uniforms: skyUniforms,
    vertexShader: `
      varying vec3 vPos;
      void main() {
        vPos = position;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 uTop;
      uniform vec3 uBottom;
      uniform float uHaze;
      varying vec3 vPos;
      void main() {
        float h = clamp(normalize(vPos).y * 0.5 + 0.5, 0.0, 1.0);
        vec3 color = mix(uBottom, uTop, pow(h, 0.85));
        float horizon = exp(-pow((h - 0.38) * 7.0, 2.0));
        color += vec3(1.0, 0.72, 0.58) * horizon * uHaze;
        gl_FragColor = vec4(color, 1.0);
      }
    `,
  }),
);
scene.add(sky);

const ambientLight = new THREE.HemisphereLight(0xffffff, 0x3a4f43, 0.66);
scene.add(ambientLight);

const sunLight = new THREE.DirectionalLight(0xffd6aa, 1.08);
sunLight.position.set(5, 8, 2);
sunLight.castShadow = CONFIG.shadow;
if (CONFIG.shadow) {
  sunLight.shadow.mapSize.width = 1024;
  sunLight.shadow.mapSize.height = 1024;
  sunLight.shadow.camera.left = -10;
  sunLight.shadow.camera.right = 10;
  sunLight.shadow.camera.top = 10;
  sunLight.shadow.camera.bottom = -10;
}
scene.add(sunLight);

const moonLight = new THREE.DirectionalLight(0x8ab5ff, 0.32);
moonLight.position.set(-5, 7, -4);
scene.add(moonLight);

const sunMesh = new THREE.Mesh(
  new THREE.SphereGeometry(0.68, 24, 24),
  new THREE.MeshBasicMaterial({ color: 0xffd7a0 }),
);
scene.add(sunMesh);

const moonMesh = new THREE.Mesh(
  new THREE.SphereGeometry(0.5, 24, 24),
  new THREE.MeshBasicMaterial({ color: 0xd9e8ff }),
);
scene.add(moonMesh);

const starsGeometry = new THREE.BufferGeometry();
const starsVertices = [];
for (let i = 0; i < 420; i += 1) {
  const angle = Math.random() * Math.PI * 2;
  const elevation = Math.random() * Math.PI * 0.5;
  const radius = rand(22, 45);
  const x = Math.cos(angle) * Math.cos(elevation) * radius;
  const y = Math.sin(elevation) * radius + 6;
  const z = Math.sin(angle) * Math.cos(elevation) * radius;
  starsVertices.push(x, y, z);
}
starsGeometry.setAttribute("position", new THREE.Float32BufferAttribute(starsVertices, 3));
const starsMaterial = new THREE.PointsMaterial({
  color: 0xe9f2ff,
  size: 0.2,
  transparent: true,
  opacity: 0,
  depthWrite: false,
});
const stars = new THREE.Points(starsGeometry, starsMaterial);
scene.add(stars);

const ground = new THREE.Mesh(
  new THREE.CircleGeometry(CONFIG.gardenRadius, 96),
  new THREE.MeshStandardMaterial({
    color: 0x7cae6a,
    roughness: 0.95,
    metalness: 0.01,
  }),
);
ground.rotation.x = -Math.PI / 2;
ground.receiveShadow = CONFIG.shadow;
scene.add(ground);

const borderRing = new THREE.Mesh(
  new THREE.TorusGeometry(CONFIG.gardenRadius + 0.08, 0.11, 14, 92),
  new THREE.MeshStandardMaterial({
    color: 0x657b54,
    roughness: 0.9,
    metalness: 0.02,
  }),
);
borderRing.rotation.x = Math.PI / 2;
borderRing.position.y = 0.03;
scene.add(borderRing);

const bowlPosition = new THREE.Vector3(0, 0, 0);

function createFoodBowl() {
  const bowl = new THREE.Group();

  const outer = new THREE.Mesh(
    new THREE.CylinderGeometry(0.76, 0.66, 0.26, 28, 1, false),
    new THREE.MeshStandardMaterial({
      color: 0xb7bec9,
      roughness: 0.36,
      metalness: 0.2,
    }),
  );
  outer.position.y = 0.14;
  outer.castShadow = CONFIG.shadow;
  outer.receiveShadow = CONFIG.shadow;
  bowl.add(outer);

  const inner = new THREE.Mesh(
    new THREE.CylinderGeometry(0.6, 0.56, 0.1, 28),
    new THREE.MeshStandardMaterial({
      color: 0x7d5a3b,
      roughness: 0.95,
      metalness: 0.01,
    }),
  );
  inner.position.y = 0.21;
  bowl.add(inner);

  const food = new THREE.Mesh(
    new THREE.CircleGeometry(0.5, 22),
    new THREE.MeshStandardMaterial({
      color: 0xd6a67a,
      roughness: 0.83,
      metalness: 0,
    }),
  );
  food.rotation.x = -Math.PI / 2;
  food.position.y = 0.26;
  bowl.add(food);

  bowl.position.copy(bowlPosition);
  scene.add(bowl);
}
createFoodBowl();

const clouds = [];
function createClouds() {
  const cloudMat = new THREE.MeshLambertMaterial({
    color: 0xffffff,
    transparent: true,
    opacity: 0.52,
  });
  for (let i = 0; i < CONFIG.cloudCount; i += 1) {
    const cloud = new THREE.Group();
    const puffCount = isMobile ? 3 : 4;
    for (let p = 0; p < puffCount; p += 1) {
      const puff = new THREE.Mesh(
        new THREE.SphereGeometry(rand(0.35, 0.7), 10, 10),
        cloudMat,
      );
      puff.position.set(rand(-0.65, 0.65), rand(-0.12, 0.18), rand(-0.3, 0.3));
      cloud.add(puff);
    }
    cloud.position.set(rand(-12, 12), rand(3.9, 7.2), rand(-8, 8));
    cloud.userData.speed = rand(0.35, 0.8);
    cloud.userData.scale = rand(0.9, 1.6);
    cloud.scale.setScalar(cloud.userData.scale);
    scene.add(cloud);
    clouds.push(cloud);
  }
}
createClouds();

const grassBlades = [];
function createGrass() {
  const bladeMat = new THREE.MeshStandardMaterial({
    color: 0x73b06f,
    roughness: 0.93,
    metalness: 0.01,
    side: THREE.DoubleSide,
  });
  const bladeGeo = new THREE.PlaneGeometry(0.07, 0.32, 1, 2);
  for (let i = 0; i < CONFIG.grassCount; i += 1) {
    const point = randomInCircle(CONFIG.gardenRadius - 0.35);
    if (point.length() < 1.55) {
      continue;
    }
    const tuft = new THREE.Group();
    tuft.position.set(point.x, 0.01, point.z);
    const bladeCount = isMobile ? 3 : 4;
    for (let b = 0; b < bladeCount; b += 1) {
      const pivot = new THREE.Group();
      pivot.position.set(rand(-0.1, 0.1), 0, rand(-0.1, 0.1));
      const blade = new THREE.Mesh(bladeGeo, bladeMat);
      blade.position.y = rand(0.12, 0.19);
      blade.rotation.y = rand(-0.6, 0.6);
      blade.rotation.x = rand(-0.24, -0.06);
      blade.scale.y = rand(0.7, 1.08);
      pivot.rotation.y = (b / bladeCount) * Math.PI * 2 + rand(-0.24, 0.24);
      pivot.add(blade);
      tuft.add(pivot);
      grassBlades.push({
        pivot,
        strength: rand(0.06, 0.17),
        offset: rand(0, Math.PI * 2),
      });
    }
    scene.add(tuft);
  }
}
createGrass();

function createStones() {
  const stoneGeo = new THREE.DodecahedronGeometry(1, 0);
  const stoneMat = new THREE.MeshStandardMaterial({
    color: 0xa5a6ac,
    roughness: 0.88,
    metalness: 0.03,
  });
  for (let i = 0; i < CONFIG.stoneCount; i += 1) {
    const point = randomInCircle(CONFIG.gardenRadius - 0.4);
    if (point.length() < 1.35) {
      continue;
    }
    const stone = new THREE.Mesh(stoneGeo, stoneMat);
    const scale = rand(0.09, 0.25);
    stone.scale.set(scale, scale * rand(0.7, 0.95), scale * rand(0.8, 1.1));
    stone.position.set(point.x, scale * 0.55, point.z);
    stone.rotation.set(rand(-0.2, 0.2), rand(0, Math.PI * 2), rand(-0.2, 0.2));
    stone.castShadow = CONFIG.shadow;
    stone.receiveShadow = CONFIG.shadow;
    scene.add(stone);
  }
}
createStones();

const flowerTypes = {
  daisy: { petals: 9, petalColor: 0xfdf1da, centerColor: 0xf6ca62, stem: 0x5f8f50, height: 0.45 },
  tulip: { petals: 6, petalColor: 0xf39b93, centerColor: 0xf0be7d, stem: 0x5f8f50, height: 0.54 },
  wild: { petals: 7, petalColor: 0xc5a8ff, centerColor: 0xf4dd94, stem: 0x5f8f50, height: 0.38 },
  blossom: { petals: 8, petalColor: 0xffc4d2, centerColor: 0xffe1ad, stem: 0x5f8f50, height: 0.48 },
  secret: { petals: 10, petalColor: 0xc9f5ff, centerColor: 0xfff2a3, stem: 0x76b5b2, height: 0.62 },
};

const flowers = [];
let spawnedDayFlowers = 0;

function isNearFlowers(position, minDistance = 0.34) {
  for (const flower of flowers) {
    const dx = flower.position.x - position.x;
    const dz = flower.position.z - position.z;
    if (dx * dx + dz * dz < minDistance * minDistance) {
      return true;
    }
  }
  return false;
}

function pickFlowerSpot() {
  for (let i = 0; i < 180; i += 1) {
    const point = randomInCircle(CONFIG.gardenRadius - 0.6);
    if (point.length() < 1.15) {
      continue;
    }
    if (isNearFlowers(point, 0.42)) {
      continue;
    }
    return point;
  }
  return randomInCircle(CONFIG.gardenRadius - 1.1);
}

function createFlower(typeName, position, delay = 0) {
  const spec = flowerTypes[typeName] || flowerTypes.daisy;
  const flower = new THREE.Group();
  flower.position.set(position.x, 0, position.z);

  const soil = new THREE.Mesh(
    new THREE.SphereGeometry(0.14, 12, 10),
    new THREE.MeshStandardMaterial({
      color: 0x7a5f45,
      roughness: 0.96,
      metalness: 0.02,
    }),
  );
  soil.scale.set(1.15, 0.24, 1.15);
  soil.position.y = 0.03;
  flower.add(soil);

  const stem = new THREE.Mesh(
    new THREE.CylinderGeometry(0.02, 0.028, spec.height, 7),
    new THREE.MeshStandardMaterial({
      color: spec.stem,
      roughness: 0.85,
      metalness: 0.02,
    }),
  );
  stem.position.y = spec.height * 0.5 + 0.02;
  stem.scale.y = 0.02;
  stem.castShadow = CONFIG.shadow;
  flower.add(stem);

  const petalPivot = new THREE.Group();
  petalPivot.position.y = spec.height + 0.02;
  petalPivot.scale.setScalar(0.05);
  petalPivot.rotation.x = 1.2;
  flower.add(petalPivot);

  const petalMat = new THREE.MeshStandardMaterial({
    color: spec.petalColor,
    roughness: 0.62,
    metalness: 0.04,
    emissive: typeName === "secret" ? 0x4fd7ff : 0x000000,
    emissiveIntensity: typeName === "secret" ? 0.55 : 0,
  });
  const petalGeo = new THREE.SphereGeometry(0.07, 8, 8);
  for (let i = 0; i < spec.petals; i += 1) {
    const petal = new THREE.Mesh(petalGeo, petalMat);
    const angle = (i / spec.petals) * Math.PI * 2;
    const radius = typeName === "tulip" ? 0.06 : 0.1;
    petal.position.set(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
    petal.scale.set(0.58, 1.05, 0.42);
    petal.rotation.y = angle;
    petal.rotation.z = typeName === "tulip" ? -0.15 : 0;
    petalPivot.add(petal);
  }

  const center = new THREE.Mesh(
    new THREE.SphereGeometry(0.05, 10, 10),
    new THREE.MeshStandardMaterial({
      color: spec.centerColor,
      roughness: 0.44,
      metalness: 0.08,
      emissive: typeName === "secret" ? 0x94f0ff : 0x000000,
      emissiveIntensity: typeName === "secret" ? 1.2 : 0,
    }),
  );
  center.position.y = 0.02;
  petalPivot.add(center);

  const dustGeometry = new THREE.BufferGeometry();
  const dustPositions = new Float32Array(27);
  for (let i = 0; i < dustPositions.length; i += 3) {
    const angle = rand(0, Math.PI * 2);
    const radius = rand(0.05, 0.28);
    dustPositions[i] = Math.cos(angle) * radius;
    dustPositions[i + 1] = rand(-0.05, 0.2);
    dustPositions[i + 2] = Math.sin(angle) * radius;
  }
  dustGeometry.setAttribute("position", new THREE.BufferAttribute(dustPositions, 3));
  const dust = new THREE.Points(
    dustGeometry,
    new THREE.PointsMaterial({
      color: typeName === "secret" ? 0xbff6ff : 0xffe1a9,
      size: typeName === "secret" ? 0.08 : 0.06,
      transparent: true,
      opacity: 0,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    }),
  );
  dust.position.y = spec.height + 0.06;
  flower.add(dust);

  flower.userData = {
    type: typeName,
    spec,
    stem,
    petalPivot,
    center,
    soil,
    dust,
    growthDelay: delay,
    growthProgress: 0,
    growthSpeed: rand(0.3, 0.42),
    fullyGrown: false,
    swayOffset: rand(0, Math.PI * 2),
  };

  scene.add(flower);
  flowers.push(flower);
  return flower;
}

function spawnDailyFlower(delay = 0) {
  const type = pickWeighted([
    { value: "daisy", weight: 0.34 },
    { value: "tulip", weight: 0.25 },
    { value: "wild", weight: 0.2 },
    { value: "blossom", weight: 0.21 },
  ]);
  const position = pickFlowerSpot();
  createFlower(type, position, delay);
}

function syncFlowersWithDate(initial = false) {
  const target = daysTogether();
  while (spawnedDayFlowers < target) {
    const delay = initial ? rand(0.3, 4.2) : 0;
    spawnDailyFlower(delay);
    spawnedDayFlowers += 1;
  }
  flowerCountEl.textContent = `Fleurs du jardin: ${spawnedDayFlowers}`;
  const message = romanticMessages[(Math.max(1, target) - 1) % romanticMessages.length];
  dailyMessageEl.textContent = message;
}

syncFlowersWithDate(true);
updateLoveTimer();
window.setInterval(updateLoveTimer, 1000);

if (new Date().getHours() < 5) {
  createFlower("secret", new THREE.Vector3(1.25, 0, -1.05), 2.2);
}

const introScene = {
  active: true,
  elapsed: 0,
  duration: 12.4,
  audioPrimed: false,
  uiShown: false,
  root: new THREE.Group(),
};

const introSoil = new THREE.Mesh(
  new THREE.SphereGeometry(0.45, 20, 16),
  new THREE.MeshStandardMaterial({
    color: 0x6d5241,
    roughness: 0.95,
    metalness: 0.01,
  }),
);
introSoil.scale.set(1.5, 0.35, 1.5);
introSoil.position.y = 0.04;
introScene.root.add(introSoil);

const introSeed = new THREE.Mesh(
  new THREE.SphereGeometry(0.06, 16, 16),
  new THREE.MeshStandardMaterial({
    color: 0xffddab,
    roughness: 0.35,
    metalness: 0.15,
    emissive: 0xffc784,
    emissiveIntensity: 1.2,
  }),
);
introSeed.position.y = 0.12;
introScene.root.add(introSeed);

const introStem = new THREE.Mesh(
  new THREE.CylinderGeometry(0.02, 0.022, 0.78, 8),
  new THREE.MeshStandardMaterial({
    color: 0x6a9a61,
    roughness: 0.86,
    metalness: 0.02,
  }),
);
introStem.position.y = 0.12;
introStem.scale.y = 0.01;
introScene.root.add(introStem);

const introPetalPivot = new THREE.Group();
introPetalPivot.position.y = 0.56;
introPetalPivot.scale.setScalar(0.01);
introPetalPivot.rotation.x = 1.25;
introScene.root.add(introPetalPivot);

const introPetalMat = new THREE.MeshStandardMaterial({
  color: 0xffd6e0,
  roughness: 0.58,
  metalness: 0.04,
  emissive: 0xffa6bf,
  emissiveIntensity: 0.35,
});
for (let i = 0; i < 8; i += 1) {
  const petal = new THREE.Mesh(new THREE.SphereGeometry(0.1, 9, 9), introPetalMat);
  const angle = (i / 8) * Math.PI * 2;
  petal.position.set(Math.cos(angle) * 0.1, 0, Math.sin(angle) * 0.1);
  petal.scale.set(0.44, 1.12, 0.35);
  petal.rotation.y = angle;
  introPetalPivot.add(petal);
}
const introCore = new THREE.Mesh(
  new THREE.SphereGeometry(0.06, 14, 14),
  new THREE.MeshStandardMaterial({
    color: 0xffefb1,
    roughness: 0.48,
    metalness: 0.04,
    emissive: 0xfff2bd,
    emissiveIntensity: 0.8,
  }),
);
introPetalPivot.add(introCore);

const introDustGeo = new THREE.BufferGeometry();
const introDustPos = new Float32Array(54);
for (let i = 0; i < introDustPos.length; i += 3) {
  const angle = rand(0, Math.PI * 2);
  const radius = rand(0.08, 0.46);
  introDustPos[i] = Math.cos(angle) * radius;
  introDustPos[i + 1] = rand(-0.06, 0.3);
  introDustPos[i + 2] = Math.sin(angle) * radius;
}
introDustGeo.setAttribute("position", new THREE.BufferAttribute(introDustPos, 3));
const introDust = new THREE.Points(
  introDustGeo,
  new THREE.PointsMaterial({
    color: 0xffe8c6,
    size: 0.07,
    transparent: true,
    opacity: 0,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  }),
);
introDust.position.y = 0.62;
introScene.root.add(introDust);

introScene.root.position.set(0, 0, 1.08);
scene.add(introScene.root);

const butterflies = [];

function createWingTexture() {
  const texCanvas = document.createElement("canvas");
  texCanvas.width = 128;
  texCanvas.height = 128;
  const ctx = texCanvas.getContext("2d");
  if (!ctx) {
    return null;
  }

  const grad = ctx.createRadialGradient(64, 64, 12, 64, 64, 62);
  grad.addColorStop(0, "#fff8f0");
  grad.addColorStop(0.35, "#ffd6c1");
  grad.addColorStop(0.7, "#c2c8ff");
  grad.addColorStop(1, "#6ba6ff");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);

  ctx.globalAlpha = 0.52;
  ctx.fillStyle = "#ffffff";
  for (let i = 0; i < 9; i += 1) {
    ctx.beginPath();
    ctx.ellipse(rand(20, 108), rand(20, 108), rand(4, 11), rand(4, 11), 0, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(texCanvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createButterflies() {
  const bodyMat = new THREE.MeshStandardMaterial({
    color: 0x5e5d6e,
    roughness: 0.72,
    metalness: 0.08,
  });
  const wingShape = new THREE.Shape();
  wingShape.moveTo(0.0, 0.0);
  wingShape.bezierCurveTo(0.18, 0.02, 0.3, 0.15, 0.28, 0.35);
  wingShape.bezierCurveTo(0.2, 0.5, 0.03, 0.48, -0.06, 0.34);
  wingShape.bezierCurveTo(-0.11, 0.22, -0.1, 0.08, 0.0, 0.0);
  const wingGeo = new THREE.ShapeGeometry(wingShape);
  wingGeo.center();
  const wingTex = createWingTexture();
  const wingPalette = [0xffb6a2, 0xffe18f, 0xb8d5ff, 0xd3b8ff, 0xffc0d9, 0x8fd8ff];

  for (let i = 0; i < CONFIG.butterflyCount; i += 1) {
    const group = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.02, 0.18, 8), bodyMat);
    body.rotation.z = Math.PI / 2;
    group.add(body);

    const wingColor = wingPalette[i % wingPalette.length];
    const wingMat = new THREE.MeshStandardMaterial({
      color: wingColor,
      roughness: 0.45,
      metalness: 0.05,
      side: THREE.DoubleSide,
      emissive: 0x101015,
      emissiveIntensity: 0.2,
      map: wingTex,
      transparent: true,
      alphaTest: 0.08,
    });

    const leftWing = new THREE.Mesh(wingGeo, wingMat);
    leftWing.position.set(0, 0, 0.09);
    leftWing.rotation.y = 0.55;
    leftWing.rotation.x = 0.15;
    leftWing.scale.set(0.42, 0.42, 0.42);
    group.add(leftWing);

    const rightWing = new THREE.Mesh(wingGeo, wingMat.clone());
    rightWing.position.set(0, 0, -0.09);
    rightWing.rotation.y = -0.55;
    rightWing.rotation.x = -0.15;
    rightWing.scale.set(0.42, 0.42, 0.42);
    group.add(rightWing);

    const butterfly = {
      group,
      leftWing,
      rightWing,
      angle: rand(0, Math.PI * 2),
      radius: rand(1.8, 4.8),
      height: rand(0.9, 1.8),
      speed: rand(0.5, 1.1),
      flapPhase: rand(0, Math.PI * 2),
      mode: "fly",
      timer: rand(4, 10),
      target: null,
    };
    group.position.set(rand(-2, 2), butterfly.height, rand(-2, 2));
    scene.add(group);
    butterflies.push(butterfly);
  }
}
createButterflies();

const fireflies = [];
function createFireflies() {
  const glowMat = new THREE.MeshBasicMaterial({
    color: 0xfff3a8,
    transparent: true,
    opacity: 0,
  });
  for (let i = 0; i < CONFIG.fireflyCount; i += 1) {
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 8), glowMat.clone());
    const anchor = randomInCircle(CONFIG.gardenRadius - 0.55);
    anchor.y = rand(0.2, 1.7);
    mesh.position.copy(anchor);
    mesh.visible = false;
    scene.add(mesh);
    fireflies.push({
      mesh,
      anchor,
      phase: rand(0, Math.PI * 2),
      speed: rand(0.5, 1.45),
      drift: rand(0.2, 0.7),
    });
  }
}
createFireflies();

const shootingStars = [];
function createShootingStars() {
  for (let i = 0; i < CONFIG.shootingStarCount; i += 1) {
    const trailPositions = new Float32Array(6);
    const trailGeometry = new THREE.BufferGeometry();
    trailGeometry.setAttribute("position", new THREE.BufferAttribute(trailPositions, 3));
    const trailMaterial = new THREE.LineBasicMaterial({
      color: 0xe8f4ff,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    const trail = new THREE.Line(trailGeometry, trailMaterial);
    trail.visible = false;
    scene.add(trail);

    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.06, 8, 8),
      new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0,
      }),
    );
    head.visible = false;
    scene.add(head);

    shootingStars.push({
      head,
      trail,
      trailPositions,
      position: new THREE.Vector3(),
      velocity: new THREE.Vector3(),
      active: false,
      life: 0,
      cooldown: rand(7, 20),
    });
  }
}
createShootingStars();

const rainGeometry = new THREE.BufferGeometry();
const rainPositions = new Float32Array(CONFIG.rainDropCount * 3);
const rainSpeeds = new Float32Array(CONFIG.rainDropCount);
for (let i = 0; i < CONFIG.rainDropCount; i += 1) {
  const idx = i * 3;
  const anchor = randomInCircle(CONFIG.gardenRadius + 0.5);
  rainPositions[idx] = anchor.x;
  rainPositions[idx + 1] = rand(0.2, 6.5);
  rainPositions[idx + 2] = anchor.z;
  rainSpeeds[i] = rand(4.8, 8.6);
}
rainGeometry.setAttribute("position", new THREE.BufferAttribute(rainPositions, 3));
const rainMaterial = new THREE.PointsMaterial({
  color: 0xaec4db,
  size: isMobile ? 0.04 : 0.03,
  transparent: true,
  opacity: 0,
  depthWrite: false,
});
const rainMesh = new THREE.Points(rainGeometry, rainMaterial);
rainMesh.visible = false;
scene.add(rainMesh);

const rainState = {
  active: false,
  blend: 0,
  timer: rand(65, 150),
  duration: 0,
  windPush: 0,
};

function createCat() {
  const root = new THREE.Group();
  root.position.set(-0.9, 0.05, 0.9);
  root.scale.setScalar(0.5);
  scene.add(root);

  const furMat = new THREE.MeshStandardMaterial({
    color: 0x9b897b,
    roughness: 0.92,
    metalness: 0.02,
  });
  const stripeMat = new THREE.MeshStandardMaterial({
    color: 0x6d5d52,
    roughness: 0.9,
    metalness: 0.02,
  });
  const lightMat = new THREE.MeshStandardMaterial({
    color: 0xc8b8aa,
    roughness: 0.94,
    metalness: 0.01,
  });

  const bodyPivot = new THREE.Group();
  root.add(bodyPivot);

  const body = new THREE.Mesh(new THREE.SphereGeometry(0.36, 20, 16), furMat);
  body.scale.set(1.35, 0.82, 0.86);
  body.position.y = 0.36;
  body.castShadow = CONFIG.shadow;
  bodyPivot.add(body);

  const belly = new THREE.Mesh(new THREE.SphereGeometry(0.21, 14, 14), lightMat);
  belly.scale.set(1.45, 0.9, 0.95);
  belly.position.set(0.06, 0.27, 0);
  bodyPivot.add(belly);

  for (let i = 0; i < 3; i += 1) {
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.03, 0.5), stripeMat);
    stripe.position.set(-0.1 + i * 0.15, 0.44, 0);
    stripe.rotation.z = rand(-0.2, 0.2);
    bodyPivot.add(stripe);
  }

  const headPivot = new THREE.Group();
  headPivot.position.set(0.44, 0.49, 0);
  bodyPivot.add(headPivot);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 18, 16), furMat);
  head.castShadow = CONFIG.shadow;
  headPivot.add(head);

  const muzzle = new THREE.Mesh(new THREE.SphereGeometry(0.11, 12, 10), lightMat);
  muzzle.scale.set(1.15, 0.75, 0.9);
  muzzle.position.set(0.07, -0.05, 0);
  headPivot.add(muzzle);

  const nose = new THREE.Mesh(
    new THREE.SphereGeometry(0.02, 10, 10),
    new THREE.MeshStandardMaterial({ color: 0xef9f9f, roughness: 0.5, metalness: 0.1 }),
  );
  nose.position.set(0.16, -0.03, 0);
  headPivot.add(nose);

  const earGeo = new THREE.ConeGeometry(0.06, 0.14, 12);
  const earLeft = new THREE.Mesh(earGeo, furMat);
  earLeft.position.set(-0.03, 0.18, 0.12);
  earLeft.rotation.set(-0.07, 0.1, -0.1);
  headPivot.add(earLeft);

  const earRight = new THREE.Mesh(earGeo, furMat);
  earRight.position.set(-0.03, 0.18, -0.12);
  earRight.rotation.set(0.07, -0.1, -0.1);
  headPivot.add(earRight);

  const eyeMat = new THREE.MeshStandardMaterial({
    color: 0x8fe26f,
    roughness: 0.22,
    metalness: 0.12,
    emissive: 0x2d6122,
    emissiveIntensity: 0.42,
  });
  const eyeGeo = new THREE.SphereGeometry(0.03, 10, 10);
  const eyeLeft = new THREE.Mesh(eyeGeo, eyeMat);
  eyeLeft.position.set(0.09, 0.03, 0.08);
  headPivot.add(eyeLeft);
  const eyeRight = eyeLeft.clone();
  eyeRight.position.z = -0.08;
  headPivot.add(eyeRight);

  const pupilMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.3 });
  const pupilGeo = new THREE.SphereGeometry(0.012, 6, 6);
  const pupilLeft = new THREE.Mesh(pupilGeo, pupilMat);
  pupilLeft.position.set(0.114, 0.03, 0.08);
  headPivot.add(pupilLeft);
  const pupilRight = pupilLeft.clone();
  pupilRight.position.z = -0.08;
  headPivot.add(pupilRight);

  const tailBase = new THREE.Group();
  tailBase.position.set(-0.49, 0.45, 0);
  bodyPivot.add(tailBase);

  const tailMat = stripeMat;
  const tailSegA = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.05, 0.26, 10), tailMat);
  tailSegA.rotation.z = Math.PI / 2.6;
  tailSegA.position.x = -0.11;
  tailBase.add(tailSegA);

  const tailMid = new THREE.Group();
  tailMid.position.set(-0.22, 0.07, 0);
  tailBase.add(tailMid);
  const tailSegB = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 0.23, 10), tailMat);
  tailSegB.rotation.z = Math.PI / 2.55;
  tailSegB.position.x = -0.11;
  tailMid.add(tailSegB);

  const tailTip = new THREE.Group();
  tailTip.position.set(-0.22, 0.05, 0);
  tailMid.add(tailTip);
  const tailSegC = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.032, 0.18, 10), tailMat);
  tailSegC.rotation.z = Math.PI / 2.5;
  tailSegC.position.x = -0.09;
  tailTip.add(tailSegC);

  function buildLeg(x, z) {
    const legPivot = new THREE.Group();
    legPivot.position.set(x, 0.25, z);
    bodyPivot.add(legPivot);

    const upper = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.055, 0.22, 9), furMat);
    upper.position.y = -0.12;
    legPivot.add(upper);

    const paw = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 10), lightMat);
    paw.position.y = -0.24;
    legPivot.add(paw);

    return legPivot;
  }

  const legs = {
    frontLeft: buildLeg(0.22, 0.18),
    frontRight: buildLeg(0.22, -0.18),
    backLeft: buildLeg(-0.2, 0.18),
    backRight: buildLeg(-0.2, -0.18),
  };

  return {
    root,
    bodyPivot,
    headPivot,
    tailBase,
    tailMid,
    tailTip,
    eyes: [eyeLeft, eyeRight],
    legs,
  };
}

const cat = createCat();

const catPoses = {
  walk: { bodyY: 0, bodyPitch: 0, headPitch: 0.05, headYaw: 0, tailLift: 0.6, tailCurl: 0.2, legAmp: 0.58, eyeOpen: 1 },
  walkToBowl: { bodyY: 0, bodyPitch: 0, headPitch: 0.06, headYaw: 0, tailLift: 0.65, tailCurl: 0.22, legAmp: 0.63, eyeOpen: 1 },
  sit: { bodyY: -0.03, bodyPitch: 0.22, headPitch: 0.04, headYaw: 0, tailLift: 0.35, tailCurl: 0.3, legAmp: 0.05, eyeOpen: 1 },
  lie: { bodyY: -0.12, bodyPitch: 0.45, headPitch: 0.25, headYaw: 0, tailLift: 0.1, tailCurl: 0.35, legAmp: 0.03, eyeOpen: 0.9 },
  stretch: { bodyY: -0.02, bodyPitch: -0.14, headPitch: -0.25, headYaw: 0, tailLift: 0.75, tailCurl: 0.15, legAmp: 0.25, eyeOpen: 1 },
  watch: { bodyY: -0.01, bodyPitch: 0.06, headPitch: -0.04, headYaw: 0, tailLift: 0.5, tailCurl: 0.24, legAmp: 0.04, eyeOpen: 1 },
  sniff: { bodyY: -0.01, bodyPitch: 0.08, headPitch: 0.35, headYaw: 0, tailLift: 0.42, tailCurl: 0.28, legAmp: 0.04, eyeOpen: 1 },
  groom: { bodyY: -0.05, bodyPitch: 0.3, headPitch: 0.48, headYaw: -0.26, tailLift: 0.38, tailCurl: 0.3, legAmp: 0.05, eyeOpen: 0.9 },
  sleep: { bodyY: -0.14, bodyPitch: 0.48, headPitch: 0.36, headYaw: 0.08, tailLift: 0.1, tailCurl: 0.3, legAmp: 0.02, eyeOpen: 0.08 },
  eat: { bodyY: -0.02, bodyPitch: 0.1, headPitch: 0.72, headYaw: 0, tailLift: 0.48, tailCurl: 0.22, legAmp: 0.05, eyeOpen: 1 },
  jump: { bodyY: -0.02, bodyPitch: -0.12, headPitch: -0.05, headYaw: 0, tailLift: 0.82, tailCurl: 0.12, legAmp: 0.6, eyeOpen: 1 },
  chase: { bodyY: 0, bodyPitch: -0.03, headPitch: 0.02, headYaw: 0, tailLift: 0.78, tailCurl: 0.18, legAmp: 0.7, eyeOpen: 1 },
  play: { bodyY: -0.03, bodyPitch: 0.12, headPitch: 0.3, headYaw: 0.2, tailLift: 0.5, tailCurl: 0.26, legAmp: 0.14, eyeOpen: 1 },
};

const catState = {
  mode: "walk",
  timer: 7,
  target: new THREE.Vector3(0.6, cat.root.position.y, -0.3),
  stride: 0,
  moving: false,
  blinkCooldown: rand(2.4, 5),
  blinkPhase: -1,
  lookPhase: rand(0, Math.PI * 2),
  lastEatAt: Date.now() - rand(0, 1800000),
  baseY: cat.root.position.y,
  jumpPhase: 0,
  footprintStep: 0,
  pawTimer: 0,
  poseCurrent: { ...catPoses.walk },
  poseTarget: { ...catPoses.walk },
};

const pawPrints = [];
const pawPrintGeometry = new THREE.CircleGeometry(0.05, 12);
pawPrintGeometry.rotateX(-Math.PI / 2);
const pawPrintMaterial = new THREE.MeshBasicMaterial({
  color: 0x3b3228,
  transparent: true,
  opacity: 0.32,
  depthWrite: false,
});

function spawnPawPrint() {
  const side = catState.footprintStep % 2 === 0 ? 0.08 : -0.08;
  const lateral = new THREE.Vector3(side, 0, 0).applyAxisAngle(Y_AXIS, cat.root.rotation.y);
  const spot = cat.root.position.clone().add(lateral);
  spot.y = 0.012;

  const print = new THREE.Mesh(pawPrintGeometry, pawPrintMaterial.clone());
  print.position.copy(spot);
  print.rotation.y = cat.root.rotation.y + rand(-0.2, 0.2);
  print.scale.set(1, 1, 0.88);
  print.material.opacity = 0.34;
  scene.add(print);

  pawPrints.push({
    mesh: print,
    life: rand(2.8, 4.5),
    maxLife: 4.5,
  });
  catState.footprintStep += 1;
}

function updatePawPrints(dt) {
  for (let i = pawPrints.length - 1; i >= 0; i -= 1) {
    const paw = pawPrints[i];
    paw.life -= dt;
    if (paw.life <= 0) {
      scene.remove(paw.mesh);
      paw.mesh.material.dispose();
      pawPrints.splice(i, 1);
      continue;
    }
    paw.mesh.material.opacity = 0.32 * clamp(paw.life / paw.maxLife, 0, 1);
  }
}

function pickCatWalkTarget(allowCenter = false) {
  for (let i = 0; i < 180; i += 1) {
    const point = randomInCircle(CONFIG.gardenRadius - 0.8);
    if (!allowCenter && point.length() < 1.2) {
      continue;
    }
    if (isNearFlowers(point, 0.45)) {
      continue;
    }
    return point;
  }
  return randomInCircle(CONFIG.gardenRadius - 1.1);
}

function setCatMode(mode, duration, target = null) {
  catState.mode = mode;
  catState.timer = duration;
  catState.poseTarget = { ...(catPoses[mode] || catPoses.walk) };
  if (target) {
    catState.target.copy(target);
  }
}

function chooseCatBehavior() {
  if (cycleState.nightFactor > 0.68 && Math.random() < 0.35) {
    setCatMode("sleep", rand(16, 34));
    return;
  }

  const mode = pickWeighted([
    { value: "walk", weight: 0.28 },
    { value: "sit", weight: 0.1 },
    { value: "lie", weight: 0.11 },
    { value: "stretch", weight: 0.09 },
    { value: "watch", weight: 0.12 },
    { value: "sniff", weight: 0.08 },
    { value: "groom", weight: 0.08 },
    { value: "chase", weight: butterflies.length > 0 ? 0.08 : 0 },
    { value: "play", weight: flowers.length > 0 ? 0.08 : 0 },
    { value: "jump", weight: 0.06 },
  ]);

  if (mode === "walk") {
    setCatMode("walk", rand(8, 18), pickCatWalkTarget());
    return;
  }
  if (mode === "chase" && butterflies.length > 0) {
    const targetButterfly = butterflies[Math.floor(Math.random() * butterflies.length)];
    const chaseTarget = targetButterfly.group.position.clone();
    chaseTarget.y = catState.baseY;
    setCatMode("chase", rand(4.5, 8.5), chaseTarget);
    return;
  }
  if (mode === "play" && flowers.length > 0) {
    const flowerTarget = flowers[Math.floor(Math.random() * flowers.length)].position.clone();
    flowerTarget.y = catState.baseY;
    setCatMode("play", rand(4.2, 8.2), flowerTarget);
    return;
  }
  if (mode === "jump") {
    setCatMode("jump", rand(1.1, 1.9), pickCatWalkTarget());
    catState.jumpPhase = 0;
    return;
  }
  setCatMode(mode, rand(5, 15));
}

function catCollision(position, margin = 0.3) {
  if (position.length() > CONFIG.gardenRadius - 0.42) {
    return true;
  }
  if (isNearFlowers(position, margin)) {
    return true;
  }
  return false;
}

const windState = {
  strength: 0.6,
  gust: 0,
};

function spawnShootingStar(star) {
  star.active = true;
  star.life = rand(0.85, 1.7);
  star.position.set(rand(-10, 10), rand(7.8, 12.5), rand(-11, -4));
  star.velocity.set(rand(-8.2, -4.8), rand(-2.8, -1.4), rand(4.4, 8.6));
  star.head.visible = true;
  star.trail.visible = true;
}

function updateShootingStars(dt) {
  for (const star of shootingStars) {
    if (!star.active) {
      star.cooldown -= dt;
      if (
        cycleState.nightFactor > 0.58 &&
        star.cooldown <= 0 &&
        Math.random() < dt * (0.22 + cycleState.nightFactor * 0.38)
      ) {
        spawnShootingStar(star);
      }
      continue;
    }

    star.life -= dt;
    if (star.life <= 0) {
      star.active = false;
      star.cooldown = rand(8, 24);
      star.head.visible = false;
      star.trail.visible = false;
      continue;
    }

    star.position.addScaledVector(star.velocity, dt);
    const tail = star.position.clone().addScaledVector(star.velocity.clone().normalize(), -0.95);

    star.head.position.copy(star.position);
    star.trailPositions[0] = star.position.x;
    star.trailPositions[1] = star.position.y;
    star.trailPositions[2] = star.position.z;
    star.trailPositions[3] = tail.x;
    star.trailPositions[4] = tail.y;
    star.trailPositions[5] = tail.z;
    star.trail.geometry.attributes.position.needsUpdate = true;

    const alpha = clamp(star.life, 0, 1);
    star.head.material.opacity = alpha;
    star.trail.material.opacity = alpha * 0.75;
  }
}

function updateWeather(dt) {
  if (rainState.active) {
    rainState.duration -= dt;
    if (rainState.duration <= 0) {
      rainState.active = false;
      rainState.timer = rand(70, 160);
    }
  } else {
    rainState.timer -= dt;
    if (rainState.timer <= 0) {
      rainState.active = true;
      rainState.duration = rand(10, 20);
    }
  }

  const targetBlend = rainState.active ? 1 : 0;
  rainState.blend = lerp(rainState.blend, targetBlend, clamp(dt * 0.8, 0, 1));
  rainState.windPush = (0.24 + Math.sin(simTime * 1.6) * 0.12) * rainState.blend;
  windState.gust = Math.sin(simTime * 0.6) * 0.12 + Math.sin(simTime * 1.8) * 0.08;
  windState.strength = 0.56 + windState.gust + rainState.blend * 0.25;

  if (rainState.blend < 0.02) {
    rainMesh.visible = false;
    rainMaterial.opacity = 0;
    return;
  }

  rainMesh.visible = true;
  rainMaterial.opacity = 0.08 + rainState.blend * 0.42;
  const attribute = rainGeometry.attributes.position;

  for (let i = 0; i < CONFIG.rainDropCount; i += 1) {
    const idx = i * 3;
    rainPositions[idx] += rainState.windPush * dt;
    rainPositions[idx + 1] -= rainSpeeds[i] * dt * (0.25 + rainState.blend * 0.75);
    rainPositions[idx + 2] += Math.sin(simTime * 1.4 + i * 0.13) * 0.001;

    if (
      rainPositions[idx + 1] < 0.12 ||
      Math.abs(rainPositions[idx]) > CONFIG.gardenRadius + 1.6 ||
      Math.abs(rainPositions[idx + 2]) > CONFIG.gardenRadius + 1.6
    ) {
      const respawn = randomInCircle(CONFIG.gardenRadius + 0.6);
      rainPositions[idx] = respawn.x;
      rainPositions[idx + 1] = rand(3.4, 6.8);
      rainPositions[idx + 2] = respawn.z;
    }
  }
  attribute.needsUpdate = true;
}

const audioState = {
  context: null,
  started: false,
  muted: false,
  master: null,
};

function createNoiseBuffer(context) {
  const buffer = context.createBuffer(1, context.sampleRate * 2, context.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < data.length; i += 1) {
    data[i] = (Math.random() * 2 - 1) * 0.18;
  }
  return buffer;
}

async function ensureAmbientAudio() {
  if (audioState.started) {
    if (audioState.context && audioState.context.state === "suspended") {
      await audioState.context.resume();
    }
    return;
  }

  const AudioContextCtor = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextCtor) {
    return;
  }

  const context = new AudioContextCtor();
  const master = context.createGain();
  master.gain.value = 0.04;
  master.connect(context.destination);

  const droneA = context.createOscillator();
  const droneB = context.createOscillator();
  const shimmer = context.createOscillator();
  const lfo = context.createOscillator();
  const lfoGain = context.createGain();
  const droneGainA = context.createGain();
  const droneGainB = context.createGain();
  const shimmerGain = context.createGain();
  const filter = context.createBiquadFilter();

  droneA.type = "sine";
  droneA.frequency.value = 174;
  droneB.type = "triangle";
  droneB.frequency.value = 261.63;
  shimmer.type = "sine";
  shimmer.frequency.value = 523.25;

  lfo.type = "sine";
  lfo.frequency.value = 0.09;
  lfoGain.gain.value = 16;

  droneGainA.gain.value = 0.42;
  droneGainB.gain.value = 0.3;
  shimmerGain.gain.value = 0.06;

  filter.type = "lowpass";
  filter.frequency.value = 620;
  filter.Q.value = 0.6;

  lfo.connect(lfoGain);
  lfoGain.connect(droneB.frequency);

  droneA.connect(droneGainA);
  droneB.connect(droneGainB);
  shimmer.connect(shimmerGain);

  droneGainA.connect(filter);
  droneGainB.connect(filter);
  shimmerGain.connect(filter);

  const noise = context.createBufferSource();
  noise.buffer = createNoiseBuffer(context);
  noise.loop = true;
  const noiseFilter = context.createBiquadFilter();
  noiseFilter.type = "lowpass";
  noiseFilter.frequency.value = 280;
  const noiseGain = context.createGain();
  noiseGain.gain.value = 0.045;
  noise.connect(noiseFilter);
  noiseFilter.connect(noiseGain);
  noiseGain.connect(filter);

  filter.connect(master);

  droneA.start();
  droneB.start();
  shimmer.start();
  lfo.start();
  noise.start();

  if (context.state === "suspended") {
    await context.resume();
  }

  audioState.context = context;
  audioState.master = master;
  audioState.started = true;
}

function updateAudioButtonLabel() {
  if (!audioState.started) {
    audioBtn.textContent = "Musique: Auto";
    return;
  }
  audioBtn.textContent = audioState.muted ? "Musique: Off" : "Musique: On";
}

function showUiPanels() {
  if (introScene.uiShown) {
    return;
  }
  hud?.classList.add("visible");
  mobileNote?.classList.add("visible");
  introScene.uiShown = true;
}

audioBtn.addEventListener("click", async () => {
  await ensureAmbientAudio();
  if (!audioState.master || !audioState.context) {
    return;
  }
  audioState.muted = !audioState.muted;
  const target = audioState.muted ? 0 : 0.04;
  audioState.master.gain.cancelScheduledValues(audioState.context.currentTime);
  audioState.master.gain.linearRampToValueAtTime(target, audioState.context.currentTime + 0.25);
  updateAudioButtonLabel();
});

window.addEventListener(
  "pointerdown",
  async () => {
    await ensureAmbientAudio();
    updateAudioButtonLabel();
  },
  { once: true },
);

followCatBtn.addEventListener("click", () => {
  followCatEnabled = !followCatEnabled;
  followCatBtn.classList.toggle("active", followCatEnabled);
  followCatBtn.textContent = followCatEnabled ? "Suivre le chat \uD83D\uDC31 (Actif)" : "Suivre le chat \uD83D\uDC31";
});

function updateCycle(dt) {
  const now = new Date();
  const realPart = (now.getHours() + now.getMinutes() / 60 + now.getSeconds() / 3600) / 24;
  cycleState.progress = (realPart + simTime / CONFIG.dayCycleSeconds) % 1;

  const sunHeight = Math.sin(cycleState.progress * Math.PI * 2 - Math.PI / 2);
  cycleState.dayFactor = clamp((sunHeight + 0.2) / 1.15, 0, 1);
  cycleState.nightFactor = 1 - cycleState.dayFactor;
  cycleState.sunsetFactor = Math.exp(-Math.pow((sunHeight + 0.03) * 4.6, 2)) * (1 - cycleState.dayFactor * 0.2);

  if (cycleState.dayFactor > 0.62) {
    cycleState.label = "Cycle: Jour lumineux";
  } else if (cycleState.sunsetFactor > 0.4) {
    cycleState.label = "Cycle: Crepuscule dore";
  } else {
    cycleState.label = "Cycle: Nuit magique";
  }
  cycleLabelEl.textContent = cycleState.label;

  tmpColorA.copy(colors.skyTopNight).lerp(colors.skyTopDay, cycleState.dayFactor).lerp(colors.skyTopSunset, cycleState.sunsetFactor);
  tmpColorB.copy(colors.skyBottomNight).lerp(colors.skyBottomDay, cycleState.dayFactor).lerp(colors.skyBottomSunset, cycleState.sunsetFactor);
  tmpColorA.lerp(colors.skyTopRain, rainState.blend * 0.75);
  tmpColorB.lerp(colors.skyBottomRain, rainState.blend * 0.75);
  skyUniforms.uTop.value.copy(tmpColorA);
  skyUniforms.uBottom.value.copy(tmpColorB);
  skyUniforms.uHaze.value = 0.08 + cycleState.sunsetFactor * 0.85 + rainState.blend * 0.12;

  scene.fog.color.copy(colors.fogNight).lerp(colors.fogDay, cycleState.dayFactor).lerp(colors.fogRain, rainState.blend * 0.85);
  scene.fog.density = 0.024 - cycleState.dayFactor * 0.006 + cycleState.nightFactor * 0.002 + rainState.blend * 0.005;

  const solarAngle = cycleState.progress * Math.PI * 2;
  sunMesh.position.set(Math.cos(solarAngle) * 11, 2 + Math.sin(solarAngle) * 8, Math.sin(solarAngle) * 4);
  moonMesh.position.set(-sunMesh.position.x * 0.88, 2 + Math.sin(solarAngle + Math.PI) * 8, -sunMesh.position.z * 0.88);

  sunLight.position.copy(sunMesh.position);
  sunLight.intensity = 0.14 + cycleState.dayFactor * 1.15 + cycleState.sunsetFactor * 0.5 - rainState.blend * 0.5;
  sunLight.color.copy(colors.sunDay).lerp(colors.sunSunset, cycleState.sunsetFactor);

  moonLight.position.copy(moonMesh.position);
  moonLight.intensity = 0.12 + cycleState.nightFactor * 0.66 - rainState.blend * 0.2;

  ambientLight.intensity = 0.38 + cycleState.dayFactor * 0.46 + cycleState.sunsetFactor * 0.12 - rainState.blend * 0.12;
  starsMaterial.opacity = smoothstep(0.35, 0.88, cycleState.nightFactor) * (1 - rainState.blend * 0.9);

  for (const cloud of clouds) {
    cloud.position.x += cloud.userData.speed * dt * (0.48 + cycleState.dayFactor * 0.6);
    if (cloud.position.x > 13) {
      cloud.position.x = -13;
      cloud.position.z = rand(-8, 8);
      cloud.position.y = rand(3.8, 7.4);
    }
    const cloudOpacity = 0.12 + cycleState.dayFactor * 0.45 + cycleState.sunsetFactor * 0.18 + rainState.blend * 0.22;
    for (const part of cloud.children) {
      part.material.opacity = cloudOpacity;
      part.material.color.setRGB(
        1 - rainState.blend * 0.28,
        1 - rainState.blend * 0.24,
        1 - rainState.blend * 0.18,
      );
    }
  }
}

function updateGrass() {
  const breeze = 0.38 + cycleState.dayFactor * 0.35 + cycleState.sunsetFactor * 0.15 + windState.strength * 0.42 + rainState.blend * 0.22;
  for (const blade of grassBlades) {
    blade.pivot.rotation.z =
      Math.sin(simTime * (1.35 + rainState.blend * 0.5) + blade.offset) *
      blade.strength *
      breeze;
  }
}

function updateFlowers(dt) {
  for (const flower of flowers) {
    const data = flower.userData;
    const growth = data.growthProgress;
    if (!data.fullyGrown) {
      data.growthDelay -= dt;
      if (data.growthDelay <= 0) {
        data.growthProgress = clamp(growth + dt * data.growthSpeed, 0, 1);
        const p = data.growthProgress;
        const stemScale = smoothstep(0, 0.6, p);
        data.stem.scale.y = Math.max(0.02, stemScale);
        data.stem.position.y = data.spec.height * 0.5 * data.stem.scale.y + 0.02;

        const bloom = smoothstep(0.42, 1, p);
        data.petalPivot.scale.setScalar(0.08 + bloom * 0.95);
        data.petalPivot.rotation.x = (1 - bloom) * 1.18;
        data.center.scale.setScalar(0.4 + bloom * 0.6);

        const soilPulse = 1 + Math.sin(clamp(p * 1.25, 0, 1) * Math.PI) * 0.18;
        data.soil.scale.set(soilPulse, 0.24, soilPulse);

        const dustOpacity = clamp(1 - Math.abs(p - 0.7) * 4.5, 0, 0.75);
        data.dust.material.opacity = dustOpacity;
        if (p >= 1) {
          data.fullyGrown = true;
          data.dust.visible = false;
        }
      }
    } else {
      const sway =
        Math.sin(simTime * (1.4 + rainState.blend * 0.85) + data.swayOffset) *
        (0.07 + windState.strength * 0.03 + rainState.blend * 0.06);
      data.petalPivot.rotation.z = sway * 0.25;
    }

    if (data.type === "secret") {
      data.center.material.emissiveIntensity = 1 + Math.sin(simTime * 2.2) * 0.28;
      data.petalPivot.children[0].material.emissiveIntensity = 0.45 + Math.sin(simTime * 1.8) * 0.12;
    }
  }
}

function updateButterflies(dt) {
  const dayActive = cycleState.dayFactor > 0.22 && rainState.blend < 0.72;
  for (const butterfly of butterflies) {
    butterfly.timer -= dt;

    if (dayActive && butterfly.timer <= 0) {
      if (butterfly.mode === "fly" && flowers.length > 0 && Math.random() < 0.44) {
        butterfly.mode = "land";
        butterfly.timer = rand(2.8, 5.4);
        butterfly.target = flowers[Math.floor(Math.random() * flowers.length)];
      } else {
        butterfly.mode = "fly";
        butterfly.timer = rand(4.5, 9.2);
      }
    }

    if (!dayActive) {
      butterfly.mode = "fly";
      butterfly.timer = rand(3, 6);
    }

    if (butterfly.mode === "fly") {
      butterfly.angle += dt * butterfly.speed * (0.8 + cycleState.dayFactor * 0.6) * (1 - rainState.blend * 0.45);
      butterfly.group.position.set(
        Math.cos(butterfly.angle) * butterfly.radius,
        butterfly.height + Math.sin(simTime * 2 + butterfly.flapPhase) * 0.16,
        Math.sin(butterfly.angle) * butterfly.radius * 0.7,
      );
    } else if (butterfly.target) {
      const targetPos = butterfly.target.position.clone();
      targetPos.y = butterfly.target.userData.spec.height + 0.18;
      butterfly.group.position.lerp(targetPos, clamp(dt * 2.4, 0, 1));
    }

    const flapSpeed = butterfly.mode === "fly" ? 18 : 8;
    const flapAmount = butterfly.mode === "fly" ? 0.85 : 0.24;
    const flap = Math.sin(simTime * flapSpeed + butterfly.flapPhase) * flapAmount;
    butterfly.leftWing.rotation.y = flap + 0.24;
    butterfly.rightWing.rotation.y = -flap - 0.24;
    butterfly.group.visible = cycleState.nightFactor < 0.93 && rainState.blend < 0.82;
  }
}

function updateFireflies() {
  const visiblePower = smoothstep(0.3, 0.95, cycleState.nightFactor) * (1 - rainState.blend * 0.65);
  for (const firefly of fireflies) {
    firefly.mesh.visible = visiblePower > 0.05;
    const t = simTime * firefly.speed + firefly.phase;
    firefly.mesh.position.set(
      firefly.anchor.x + Math.sin(t * 0.9) * firefly.drift,
      firefly.anchor.y + Math.sin(t * 1.1) * 0.22 + Math.cos(t * 0.7) * 0.12,
      firefly.anchor.z + Math.cos(t) * firefly.drift,
    );
    firefly.mesh.material.opacity = (0.18 + Math.sin(t * 3.4) * 0.12) * visiblePower;
  }
}

function updateCat(dt) {
  const nowMs = Date.now();

  if (nowMs - catState.lastEatAt > 3600000 && catState.mode !== "walkToBowl" && catState.mode !== "eat") {
    setCatMode("walkToBowl", 30, new THREE.Vector3(rand(-0.3, 0.3), 0, rand(-0.3, 0.3)));
  }

  catState.timer -= dt;
  catState.moving = false;
  cat.root.position.y = lerp(cat.root.position.y, catState.baseY, clamp(dt * 9, 0, 1));

  if (catState.mode === "chase" && butterflies.length > 0) {
    let nearest = butterflies[0];
    let best = Number.POSITIVE_INFINITY;
    for (const butterfly of butterflies) {
      const d = butterfly.group.position.distanceToSquared(cat.root.position);
      if (d < best) {
        best = d;
        nearest = butterfly;
      }
    }
    catState.target.copy(nearest.group.position);
    catState.target.y = catState.baseY;
  }

  if (catState.mode === "play" && flowers.length > 0 && Math.random() < dt * 0.9) {
    const playfulFlower = flowers[Math.floor(Math.random() * flowers.length)].position.clone();
    playfulFlower.y = catState.baseY;
    catState.target.copy(playfulFlower);
  }

  const movingMode =
    catState.mode === "walk" ||
    catState.mode === "walkToBowl" ||
    catState.mode === "chase" ||
    catState.mode === "play";

  if (movingMode) {
    const toTarget = new THREE.Vector3().subVectors(catState.target, cat.root.position);
    toTarget.y = 0;
    const distance = toTarget.length();
    if (distance < 0.2) {
      if (catState.mode === "walkToBowl") {
        setCatMode("eat", rand(8, 14));
      } else if (catState.mode === "chase") {
        setCatMode("jump", rand(1.1, 1.7), pickCatWalkTarget());
        catState.jumpPhase = 0;
      } else if (catState.mode === "play") {
        setCatMode("sniff", rand(4, 8));
      } else {
        chooseCatBehavior();
      }
    } else {
      const direction = toTarget.normalize();
      const speed =
        catState.mode === "walkToBowl"
          ? 0.83
          : catState.mode === "chase"
            ? 1.08
            : catState.mode === "play"
              ? 0.72
              : 0.66;
      const step = Math.min(speed * dt, distance);
      const next = new THREE.Vector3().copy(cat.root.position).addScaledVector(direction, step);

      const blocked = catCollision(
        next,
        catState.mode === "walkToBowl" ? 0.24 : catState.mode === "chase" ? 0.2 : 0.3,
      );
      if (blocked) {
        if (catState.mode === "walkToBowl") {
          const detour = pickCatWalkTarget(true);
          catState.target.set(detour.x * 0.6, 0, detour.z * 0.6);
        } else {
          catState.target.copy(pickCatWalkTarget());
        }
      } else {
        cat.root.position.copy(next);
        catState.moving = true;
        catState.stride += step * 22;
        const yaw = Math.atan2(direction.x, direction.z);
        cat.root.rotation.y = lerpAngle(cat.root.rotation.y, yaw, clamp(dt * 7.5, 0, 1));

        catState.pawTimer -= dt;
        if (catState.pawTimer <= 0 && rainState.blend < 0.85) {
          spawnPawPrint();
          catState.pawTimer = rand(0.11, 0.2);
        }
      }
    }
  } else if (catState.mode === "jump") {
    catState.jumpPhase = clamp(catState.jumpPhase + dt * 2.3, 0, 1);
    const arc = Math.sin(catState.jumpPhase * Math.PI);
    cat.root.position.y = catState.baseY + arc * 0.14;

    const toTarget = new THREE.Vector3().subVectors(catState.target, cat.root.position);
    toTarget.y = 0;
    const distance = toTarget.length();
    if (distance > 0.05) {
      const direction = toTarget.normalize();
      const jumpStep = Math.min(distance, dt * 0.7);
      cat.root.position.addScaledVector(direction, jumpStep);
      catState.stride += jumpStep * 30;
      const yaw = Math.atan2(direction.x, direction.z);
      cat.root.rotation.y = lerpAngle(cat.root.rotation.y, yaw, clamp(dt * 8, 0, 1));
    }

    if (catState.timer <= 0 || catState.jumpPhase >= 1) {
      cat.root.position.y = catState.baseY;
      chooseCatBehavior();
    }
  } else if (catState.mode === "eat") {
    cat.root.rotation.y = lerpAngle(cat.root.rotation.y, Math.atan2(-cat.root.position.x, -cat.root.position.z), clamp(dt * 3.5, 0, 1));
    if (catState.timer <= 0) {
      catState.lastEatAt = Date.now();
      setCatMode("walk", rand(8, 16), pickCatWalkTarget());
    }
  } else if (catState.timer <= 0) {
    chooseCatBehavior();
  }

  const targetPose = catState.poseTarget;
  const pose = catState.poseCurrent;
  const smoothing = clamp(dt * 5.4, 0, 1);
  for (const key of Object.keys(pose)) {
    pose[key] = lerp(pose[key], targetPose[key], smoothing);
  }

  if (catState.mode === "watch" && butterflies.length > 0) {
    let nearest = butterflies[0];
    let bestDistance = Number.POSITIVE_INFINITY;
    for (const butterfly of butterflies) {
      const d = butterfly.group.position.distanceToSquared(cat.root.position);
      if (d < bestDistance) {
        bestDistance = d;
        nearest = butterfly;
      }
    }
    const local = nearest.group.position.clone().sub(cat.root.position);
    const heading = Math.atan2(local.x, local.z);
    const relative = Math.atan2(Math.sin(heading - cat.root.rotation.y), Math.cos(heading - cat.root.rotation.y));
    pose.headYaw = clamp(relative, -0.6, 0.6);
  }

  catState.blinkCooldown -= dt;
  if (catState.blinkCooldown <= 0 && catState.blinkPhase < 0) {
    catState.blinkPhase = 0;
    catState.blinkCooldown = rand(2.3, 5.1);
  }

  let blinkFactor = 1;
  if (catState.blinkPhase >= 0) {
    catState.blinkPhase += dt * 8.5;
    blinkFactor = Math.abs(Math.cos(catState.blinkPhase * Math.PI));
    if (catState.blinkPhase > 1) {
      catState.blinkPhase = -1;
      blinkFactor = 1;
    }
  }

  const baseBounce = catState.moving ? Math.sin(catState.stride * 2) * 0.02 : Math.sin(simTime * 3) * 0.004;
  cat.bodyPivot.position.y = pose.bodyY + baseBounce;
  cat.bodyPivot.rotation.x = pose.bodyPitch;

  const headScan = Math.sin(simTime * 0.8 + catState.lookPhase) * 0.17;
  cat.headPivot.rotation.x =
    pose.headPitch +
    (catState.mode === "eat" ? Math.sin(simTime * 11) * 0.07 : 0) +
    (catState.mode === "play" ? Math.sin(simTime * 7.5) * 0.08 : 0);
  cat.headPivot.rotation.y = pose.headYaw + headScan * (catState.moving ? 0.35 : 0.6);

  cat.tailBase.rotation.y = Math.sin(simTime * 1.6) * 0.2;
  cat.tailBase.rotation.x = pose.tailLift + Math.sin(simTime * 2.2 + 0.5) * 0.07 + (catState.moving ? Math.sin(catState.stride) * 0.09 : 0);
  cat.tailMid.rotation.x = pose.tailCurl + Math.sin(simTime * 2.8 + 0.9) * 0.07;
  cat.tailTip.rotation.x = pose.tailCurl + Math.sin(simTime * 3.2 + 1.6) * 0.09;

  let stepAmplitude = pose.legAmp;
  if (!catState.moving) {
    stepAmplitude *= 0.08;
  }
  const phase = catState.stride;
  const pairA = Math.sin(phase) * stepAmplitude;
  const pairB = -pairA;

  cat.legs.frontLeft.rotation.x = pairA;
  cat.legs.backRight.rotation.x = pairA;
  cat.legs.frontRight.rotation.x = pairB;
  cat.legs.backLeft.rotation.x = pairB;

  if (catState.mode === "groom") {
    cat.legs.frontRight.rotation.x = -0.8 + Math.sin(simTime * 8) * 0.15;
  }
  if (catState.mode === "stretch") {
    cat.legs.frontLeft.rotation.x = -0.42;
    cat.legs.frontRight.rotation.x = -0.42;
    cat.legs.backLeft.rotation.x = 0.34;
    cat.legs.backRight.rotation.x = 0.34;
  }
  if (catState.mode === "play") {
    cat.legs.frontLeft.rotation.x = -0.22 + Math.sin(simTime * 6.8) * 0.22;
  }

  const eyeOpen = clamp(pose.eyeOpen * blinkFactor, 0.05, 1);
  for (const eye of cat.eyes) {
    eye.scale.y = eyeOpen;
  }
}

function updateIntro(dt) {
  if (!introScene.active) {
    return;
  }

  introScene.elapsed += dt;
  const t = introScene.elapsed;
  const introSeedGlow = 1.1 + Math.sin(t * 7) * 0.32;
  introSeed.material.emissiveIntensity = introSeedGlow;
  introSeed.scale.setScalar(0.9 + Math.sin(t * 2.8) * 0.08);

  const stemGrowth = smoothstep(1.8, 5.1, t);
  introStem.scale.y = Math.max(0.01, stemGrowth);
  introStem.position.y = 0.12 + stemGrowth * 0.36;

  const bloom = smoothstep(4.8, 7.6, t);
  introPetalPivot.scale.setScalar(0.08 + bloom * 0.92);
  introPetalPivot.rotation.x = (1 - bloom) * 1.15;
  introDust.material.opacity = clamp(smoothstep(6.4, 7.7, t) * 0.75, 0, 0.75);

  if (t > 3.4) {
    introText.classList.add("visible");
  }

  // Attempt ambient audio during intro; browsers may ignore it until user gesture.
  if (!introScene.audioPrimed && t > 1.2) {
    introScene.audioPrimed = true;
    ensureAmbientAudio()
      .then(() => {
        updateAudioButtonLabel();
      })
      .catch(() => {});
  }

  if (t >= introScene.duration) {
    introScene.active = false;
    introOverlay.classList.add("hidden");
    showUiPanels();
    setTimeout(() => {
      introOverlay.style.display = "none";
    }, 1700);
  }
}

function updateCamera(dt) {
  const desiredPos = new THREE.Vector3();
  const desiredLook = new THREE.Vector3();

  if (introScene.active) {
    const t = introScene.elapsed;
    const pullBack = smoothstep(7.8, 12, t);
    const startPos = new THREE.Vector3(0, 0.72, 2.2);
    const endPos = new THREE.Vector3(0, isMobile ? 2.7 : 3.4, isMobile ? 6.2 : 7.4);
    desiredPos.lerpVectors(startPos, endPos, pullBack);
    desiredLook.lerpVectors(
      new THREE.Vector3(0, 0.26, 1.08),
      new THREE.Vector3(0, 0.75, 0),
      pullBack,
    );
  } else if (followCatEnabled) {
    const behind = new THREE.Vector3(0, isMobile ? 1.3 : 1.6, isMobile ? 2.1 : 2.6);
    behind.applyAxisAngle(Y_AXIS, cat.root.rotation.y + Math.PI);
    desiredPos.copy(cat.root.position).add(behind);
    desiredLook.copy(cat.root.position).add(new THREE.Vector3(0, 0.48, 0));
  } else {
    desiredPos.set(
      Math.sin(simTime * 0.09) * 7.1,
      (isMobile ? 2.75 : 3.35) + Math.sin(simTime * 0.22) * 0.18,
      Math.cos(simTime * 0.07) * 6.8,
    );
    desiredLook.set(0, 0.66 + Math.sin(simTime * 0.18) * 0.05, 0);
  }

  const camLerp = 1 - Math.exp(-dt * 2.4);
  const lookLerp = 1 - Math.exp(-dt * 3.1);
  camera.position.lerp(desiredPos, camLerp);
  smoothLookTarget.lerp(desiredLook, lookLerp);
  camera.lookAt(smoothLookTarget);
}

let flowerSyncTimer = 0;

function update(dt) {
  simTime += dt;
  updateIntro(dt);
  updateWeather(dt);
  updateCycle(dt);
  updateShootingStars(dt);
  updateGrass();
  updateFlowers(dt);
  updateButterflies(dt);
  updateFireflies();
  updateCat(dt);
  updatePawPrints(dt);
  updateCamera(dt);

  flowerSyncTimer += dt;
  if (flowerSyncTimer > 18) {
    flowerSyncTimer = 0;
    syncFlowersWithDate(false);
  }
}

function render() {
  renderer.render(scene, camera);
}

function animate() {
  const dt = Math.min(clock.getDelta(), 0.033);
  update(dt);
  render();
  requestAnimationFrame(animate);
}

requestAnimationFrame(animate);

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isMobile ? 1.5 : 2));
}

window.addEventListener("resize", onResize);
updateAudioButtonLabel();

window.render_game_to_text = () =>
  (() => {
    const diffMs = Math.max(0, Date.now() - relationshipStart.getTime());
    const totalSeconds = Math.floor(diffMs / 1000);
    return JSON.stringify({
      coordinate_system: "x right, y up, z forward",
      phase: introScene.active ? "intro" : "garden",
      cycle: cycleState.label,
      weather: rainState.blend > 0.45 ? "rain" : "clear",
      counts: {
        flowers: spawnedDayFlowers,
        butterflies: butterflies.filter((b) => b.group.visible).length,
        fireflies_visible: fireflies.filter((f) => f.mesh.visible).length,
        paw_prints: pawPrints.length,
        shooting_stars: shootingStars.filter((s) => s.active).length,
      },
      timer: {
        days: Math.floor(totalSeconds / 86400),
        hours: Math.floor((totalSeconds % 86400) / 3600),
        minutes: Math.floor((totalSeconds % 3600) / 60),
        seconds: totalSeconds % 60,
      },
      cat: {
        mode: catState.mode,
        position: {
          x: Number(cat.root.position.x.toFixed(2)),
          y: Number(cat.root.position.y.toFixed(2)),
          z: Number(cat.root.position.z.toFixed(2)),
        },
        follow_camera: followCatEnabled,
      },
      bowl: { x: 0, z: 0 },
    });
  })();

window.advanceTime = (ms) => {
  const steps = Math.max(1, Math.round(ms / (1000 / 60)));
  const dt = ms / 1000 / steps;
  for (let i = 0; i < steps; i += 1) {
    update(dt);
  }
  render();
};

function initCinematicImmersionOverlay() {
  const existing = document.getElementById("cinematic-parallax");
  if (existing) {
    return;
  }

  const parallaxRoot = document.createElement("div");
  parallaxRoot.id = "cinematic-parallax";
  parallaxRoot.setAttribute("aria-hidden", "true");
  parallaxRoot.innerHTML = `
    <div class="parallax-layer layer-sky"></div>
    <div class="parallax-layer layer-mountains"></div>
    <div class="parallax-layer layer-torii"></div>
    <div class="parallax-layer layer-trees"></div>
    <div class="parallax-layer layer-lanterns"></div>
    <div class="parallax-layer layer-mist"></div>
    <div id="sakura-petals"></div>
    <div id="ambient-fireflies"></div>
  `;
  document.body.appendChild(parallaxRoot);

  const magicLayer = document.createElement("div");
  magicLayer.id = "magic-particles";
  magicLayer.setAttribute("aria-hidden", "true");
  document.body.appendChild(magicLayer);

  const lanternLayer = parallaxRoot.querySelector(".layer-lanterns");
  const lanternCount = isMobile ? 4 : 7;
  for (let i = 0; i < lanternCount; i += 1) {
    const lantern = document.createElement("div");
    lantern.className = "floating-lantern";
    lantern.style.left = `${rand(8, 92)}%`;
    lantern.style.top = `${rand(14, 66)}%`;
    lantern.style.setProperty("--float-dur", `${rand(6.8, 11.8)}s`);
    lantern.style.animationDelay = `${rand(0, 4)}s`;
    lanternLayer?.appendChild(lantern);
  }

  const petalContainer = parallaxRoot.querySelector("#sakura-petals");
  const petalCount = isMobile ? 16 : 28;
  for (let i = 0; i < petalCount; i += 1) {
    const petal = document.createElement("span");
    petal.className = "sakura-petal";
    petal.style.left = `${rand(-8, 105)}%`;
    petal.style.setProperty("--drift-x", `${rand(-70, 90)}px`);
    petal.style.setProperty("--fall-dur", `${rand(9, 16)}s`);
    petal.style.animationDelay = `${rand(-15, 0)}s`;
    petalContainer?.appendChild(petal);
  }

  const fireflyContainer = parallaxRoot.querySelector("#ambient-fireflies");
  const screenFireflies = [];
  const fireflyCount = isMobile ? 11 : 18;
  for (let i = 0; i < fireflyCount; i += 1) {
    const firefly = document.createElement("span");
    firefly.className = "screen-firefly";
    fireflyContainer?.appendChild(firefly);
    screenFireflies.push({
      el: firefly,
      x: rand(0.08, 0.92),
      y: rand(0.18, 0.88),
      vx: rand(-0.018, 0.018),
      vy: rand(-0.014, 0.014),
      phase: rand(0, Math.PI * 2),
    });
  }

  let pointerTargetX = 0;
  let pointerTargetY = 0;
  let pointerSmoothX = 0;
  let pointerSmoothY = 0;
  window.addEventListener("pointermove", (event) => {
    pointerTargetX = event.clientX / window.innerWidth - 0.5;
    pointerTargetY = event.clientY / window.innerHeight - 0.5;
  });

  function spawnMagicDot(bounds) {
    const dot = document.createElement("span");
    dot.className = "magic-dot";
    dot.style.left = `${bounds.left + rand(0, bounds.width)}px`;
    dot.style.top = `${bounds.top + rand(0, bounds.height)}px`;
    dot.style.animationDuration = `${rand(1.7, 2.8)}s`;
    magicLayer.appendChild(dot);
    dot.addEventListener("animationend", () => dot.remove(), { once: true });
  }

  const emissionTargets = [hud, document.getElementById("love-timer"), document.querySelector(".hud-actions")].filter(Boolean);
  let sparkTimer = 0;

  function animateOverlay() {
    pointerSmoothX += (pointerTargetX - pointerSmoothX) * 0.08;
    pointerSmoothY += (pointerTargetY - pointerSmoothY) * 0.08;

    parallaxRoot.style.setProperty("--parallax-x", `${pointerSmoothX * 26}px`);
    parallaxRoot.style.setProperty("--parallax-y", `${pointerSmoothY * 22}px`);

    for (const fly of screenFireflies) {
      fly.x += fly.vx * (1 + Math.abs(pointerSmoothX) * 2.3);
      fly.y += fly.vy * (1 + Math.abs(pointerSmoothY) * 2.1);

      if (fly.x > 1.04) {
        fly.x = -0.04;
      } else if (fly.x < -0.04) {
        fly.x = 1.04;
      }
      if (fly.y > 1.06) {
        fly.y = -0.06;
      } else if (fly.y < -0.06) {
        fly.y = 1.06;
      }

      const bobX = Math.sin(simTime * 0.6 + fly.phase) * 0.012 + pointerSmoothX * 0.05;
      const bobY = Math.cos(simTime * 0.7 + fly.phase) * 0.01 + pointerSmoothY * 0.04;
      fly.el.style.left = `${(fly.x + bobX) * 100}%`;
      fly.el.style.top = `${(fly.y + bobY) * 100}%`;
      fly.el.style.opacity = `${0.42 + Math.sin(simTime * 2.4 + fly.phase) * 0.22}`;
    }

    sparkTimer += 1 / 60;
    if (sparkTimer > 0.11) {
      sparkTimer = 0;
      for (const target of emissionTargets) {
        if (Math.random() < 0.35) {
          spawnMagicDot(target.getBoundingClientRect());
        }
      }
    }

    requestAnimationFrame(animateOverlay);
  }

  requestAnimationFrame(animateOverlay);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initCinematicImmersionOverlay, { once: true });
} else {
  initCinematicImmersionOverlay();
}


