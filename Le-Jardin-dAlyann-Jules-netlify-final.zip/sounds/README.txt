Reserved for ambient loops and extra sound effects.

