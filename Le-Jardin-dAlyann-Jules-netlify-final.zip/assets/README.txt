Reserved for textures, icons, and decorative art assets.

